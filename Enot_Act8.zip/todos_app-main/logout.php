<link rel="stylesheet" href="assets/style.css">          
<link rel="stylesheet" href="assets/scifi.css">
<?php
session_start();
session_unset();
session_destroy();
header("Location: index.php");
exit;
?>