<?php
include 'db.php';

try {
    // Check if tags column exists
    $stmt = $pdo->prepare("SHOW COLUMNS FROM todos LIKE 'tags'");
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE todos ADD COLUMN tags VARCHAR(500) DEFAULT NULL COMMENT 'Comma-separated tags'");
        echo "✓ Migration successful: Added 'tags' column to todos table\n";
    } else {
        echo "✓ Migration already applied: 'tags' column exists\n";
    }
} catch (Exception $e) {
    echo "✗ Migration failed: " . $e->getMessage() . "\n";
}
?>
