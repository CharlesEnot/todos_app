javascript
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', e => {
            if (!form.reportValidity()) {
                e.preventDefault();
                return;
            }

            const pass = form.querySelector('[name="password"]');
            if (pass.value.length < 8) {
                alert("Password must be at least 8 characters!");
                e.preventDefault();
            }
        });
    });
});
