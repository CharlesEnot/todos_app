<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit;
}

include 'db.php';

$user_id = $_SESSION['user_id'];

// Build query with same filters as todos.php
$where = "WHERE t.user_id = ?";
$params = [$user_id];

if ($_GET['search'] ?? '') {
    $s = "%{$_GET['search']}%";
    $where .= " AND (t.title LIKE ? OR t.description LIKE ?)";
    $params[] = $s;
    $params[] = $s;
}
if ($_GET['status'] ?? '') {
    $where .= " AND t.status = ?";
    $params[] = $_GET['status'];
}
if ($_GET['category'] ?? '') {
    $where .= " AND t.category_id = ?";
    $params[] = $_GET['category'];
}

// Fetch all matching todos (no limit for export)
$stmt = $pdo->prepare("SELECT t.id, t.title, t.description, t.status, t.priority, t.due_date, c.name as category, t.created_at FROM todos t LEFT JOIN categories c ON t.category_id = c.id $where ORDER BY t.created_at DESC");
$stmt->execute($params);
$todos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set CSV headers
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="todos_' . date('Y-m-d_H-i-s') . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Write CSV header
fputcsv($output, ['ID', 'Title', 'Description', 'Status', 'Priority', 'Due Date', 'Category', 'Created At']);

// Write data rows
foreach ($todos as $row) {
    fputcsv($output, [
        $row['id'],
        $row['title'],
        $row['description'],
        $row['status'],
        $row['priority'],
        $row['due_date'] ? date('m/d/Y', strtotime($row['due_date'])) : '',
        $row['category'] ?? '',
        date('m/d/Y H:i', strtotime($row['created_at']))
    ]);
}

fclose($output);
exit;
?>
