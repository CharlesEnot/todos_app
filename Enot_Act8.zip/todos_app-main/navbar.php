<link rel="stylesheet" href="assets/style.css">          
<link rel="stylesheet" href="assets/scifi.css">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php"><strong>TODO App</strong></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
                <li class="nav-item"><a class="nav-link" href="todos.php">TODOs</a></li>
            </ul>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
            <span class="dark-toggle" onclick="toggleDarkMode()">
                🌙
            </span>
        </div>
    </div>
</nav>
<script>
function toggleDarkMode() {
  let body = document.body;
  body.classList.toggle("light-mode");

  if(body.classList.contains("light-mode")) {
    localStorage.setItem("mode", "light");
  } else {
    localStorage.removeItem("mode");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("mode") === "light") {
    document.body.classList.add("light-mode");
  }
});
</script>
